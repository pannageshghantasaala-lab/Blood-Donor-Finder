import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const extractToken = (req) => {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  return scheme === 'Bearer' && token ? token : null;
};

// Requires a valid JWT. Attaches the user document to req.user.
export const protect = async (req, res, next) => {
  try {
    const token = extractToken(req);
    if (!token) {
      res.status(401);
      throw new Error('Not authorized: token missing');
    }

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      res.status(401);
      throw new Error('Not authorized: invalid or expired token');
    }

    const user = await User.findById(decoded.id);
    if (!user) {
      res.status(401);
      throw new Error('Not authorized: user no longer exists');
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
};

// Like protect, but never rejects. Sets req.user if a valid token is sent.
// Used on public routes that show more (e.g. donor contact details) to logged-in users.
export const optionalAuth = async (req, _res, next) => {
  try {
    const token = extractToken(req);
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id);
    }
  } catch {
    // invalid or expired token on a public route: treat as a guest
  }
  next();
};

// Role gate. Use after protect: router.delete('/:id', protect, restrictTo('admin'), ...)
export const restrictTo =
  (...roles) =>
  (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      res.status(403);
      return next(new Error('Forbidden: you do not have permission to do this'));
    }
    next();
  };
