import mongoose from 'mongoose';
import { BLOOD_GROUPS, AVAILABILITY, DONATION_GAP_DAYS } from '../constants/index.js';

const MS_PER_DAY = 24 * 60 * 60 * 1000;

const donorSchema = new mongoose.Schema(
  {
    // One donor profile per user account.
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      unique: true,
    },
    fullName: {
      type: String,
      required: [true, 'Full name is required'],
      trim: true,
      maxlength: 80,
    },
    bloodGroup: {
      type: String,
      required: [true, 'Blood group is required'],
      enum: {
        values: BLOOD_GROUPS,
        message: 'Blood group must be one of: ' + BLOOD_GROUPS.join(', '),
      },
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
      match: [/^\+?[0-9\s-]{7,15}$/, 'Please provide a valid phone number'],
    },
    contactEmail: {
      type: String,
      trim: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid contact email'],
    },
    city: { type: String, required: [true, 'City is required'], trim: true, maxlength: 60 },
    state: { type: String, required: [true, 'State is required'], trim: true, maxlength: 60 },
    availability: {
      type: String,
      enum: Object.values(AVAILABILITY),
      default: AVAILABILITY.AVAILABLE,
    },
    lastDonationDate: {
      type: Date,
      validate: {
        validator: (v) => !v || v <= new Date(),
        message: 'Last donation date cannot be in the future',
      },
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Earliest date this donor may donate again (null if never donated / unknown).
donorSchema.virtual('nextEligibleDate').get(function () {
  if (!this.lastDonationDate) return null;
  return new Date(this.lastDonationDate.getTime() + DONATION_GAP_DAYS * MS_PER_DAY);
});

// Marked Available AND past the minimum donation gap.
donorSchema.virtual('isEligible').get(function () {
  if (this.availability !== AVAILABILITY.AVAILABLE) return false;
  const next = this.nextEligibleDate;
  return !next || next <= new Date();
});

// Main search path: blood group + state + city (+ availability).
// Case-insensitive collation lets "hyderabad" match "Hyderabad".
// Queries must use the same collation to hit this index:
//   Donor.find(filter).collation({ locale: 'en', strength: 2 })
donorSchema.index(
  { bloodGroup: 1, state: 1, city: 1, availability: 1 },
  { collation: { locale: 'en', strength: 2 } }
);

const Donor = mongoose.model('Donor', donorSchema);
export default Donor;
