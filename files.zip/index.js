export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const AVAILABILITY = Object.freeze({
  AVAILABLE: 'Available',
  UNAVAILABLE: 'Unavailable',
});

export const ROLES = Object.freeze({
  USER: 'user',
  ADMIN: 'admin',
});

// Minimum gap between whole-blood donations (days).
export const DONATION_GAP_DAYS = 56;
